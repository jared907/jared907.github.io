package com.example.eventtracker_jaredbatin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Small utility for runtime SEND_SMS permission.
 * - hasSmsPermission: read current grant state
 * - requestSmsPermission: trigger runtime permission dialog
 * - openAppSettings: deep-link to this app's system settings page
 */
public class SmsPermissionHelper {
    /** @return true if SEND_SMS is currently granted for this app context. */
    public static boolean hasSmsPermission(Context ctx) {
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests SEND_SMS from the user. Result is delivered to Activity#onRequestPermissionsResult.
     * @param act hosting activity
     * @param requestCode app-defined request code to identify the response
     */
    public static void requestSmsPermission(Activity act, int requestCode) {
        ActivityCompat.requestPermissions(act,
                new String[]{Manifest.permission.SEND_SMS}, requestCode);
    }

    /**
     * Opens the system App Settings screen for this app so the user can manage permissions.
     * Useful after a permanent denial ("Don't ask again").
     */
    public static void openAppSettings(Context ctx) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", ctx.getPackageName(), null));
        ctx.startActivity(i);
    }
}
