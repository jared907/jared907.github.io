package com.example.eventtracker_jaredbatin;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtracker_jaredbatin.data.Repo;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Calendar;
import java.util.Date;

/**
 * Screen to create a new event.
 * - Collects title/date/time + optional description/location/notes
 * - Allows toggling app notification + SMS reminder (permission checked elsewhere)
 * - Persists to SQLite via Repo and optionally sends same-day SMS immediately
 */
public class AddEventActivity extends AppCompatActivity {

    private String username;                 // current logged-in user (owner)
    private final Calendar cal = Calendar.getInstance(); // working date/time
    private TextView tvChosen, tvSmsPerm;    // live date/time summary + SMS perm label

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Owner is passed from EventsActivity
        username = getIntent().getStringExtra("username");

        // Inputs for event fields
        EditText etTitle = findViewById(R.id.etTitle);
        EditText etDescription = findViewById(R.id.etDescription);
        EditText etLocation = findViewById(R.id.etLocation);
        EditText etNotes = findViewById(R.id.etNotes);
        Switch swAppNotification = findViewById(R.id.swAppNotification);
        Switch swSms = findViewById(R.id.swSms);

        // Date/time pickers and action buttons
        Button btnPickDate = findViewById(R.id.btnPickDate);
        Button btnPickTime = findViewById(R.id.btnPickTime);
        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnCreate = findViewById(R.id.btnCreate);
        tvChosen = findViewById(R.id.tvChosen);
        tvSmsPerm = findViewById(R.id.tvSmsPermStatus);

        // Pick date -> updates calendar + summary label
        btnPickDate.setOnClickListener(v -> {
            new DatePickerDialog(this, (dp, y, m, d) -> {
                cal.set(Calendar.YEAR, y);
                cal.set(Calendar.MONTH, m);
                cal.set(Calendar.DAY_OF_MONTH, d);
                updateChosen();
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });

        // Pick time -> updates calendar + summary label
        btnPickTime.setOnClickListener(v -> {
            new TimePickerDialog(this, (tp, hh, mm) -> {
                cal.set(Calendar.HOUR_OF_DAY, hh);
                cal.set(Calendar.MINUTE, mm);
                cal.set(Calendar.SECOND, 0);
                updateChosen();
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
                    android.text.format.DateFormat.is24HourFormat(this)).show();
        });

        // Cancel -> close without saving
        btnCancel.setOnClickListener(v -> finish());

        // Create -> validate title, insert row, optionally send same-day SMS, then finish
        btnCreate.setOnClickListener(v -> {
            String title = etTitle.getText() == null ? "" : etTitle.getText().toString().trim();
            if (title.isEmpty()) { toast("Enter a title"); return; }

            // Minimal validation: make sure user picked a date/time (not the default "now")
            // We consider it "picked" if tvChosen no longer says the default label
            if (tvChosen.getText() != null && tvChosen.getText().toString().toLowerCase().contains("no date/time")) {
                toast("Pick a date and time");
                return;
            }

            Repo repo = Repo.getInstance(this);

            // Save event first (core function)
            repo.addEvent(
                    username,
                    title,
                    cal.getTimeInMillis(),
                    safeText(etDescription),
                    safeText(etLocation),
                    safeText(etNotes),
                    swAppNotification.isChecked(),
                    swSms.isChecked()
            );

            // If user enabled SMS and event is today, try to send immediate reminder
            if (swSms.isChecked()) {
                if (!SmsPermissionHelper.hasSmsPermission(this)) {
                    toast("SMS permission is off. Enable it in Settings to use SMS reminders.");
                } else if (!isToday(cal.getTimeInMillis())) {
                    // Do nothing for non-today events (minimal scope: no scheduling added)
                } else {
                    String dest = repo.getUserPhone(username);

                    if (dest == null || dest.trim().isEmpty()) {
                        toast("No phone number saved for this account.");
                    } else {
                        String msg = "Reminder: " + title + " today at " +
                                java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(cal.getTime());
                        try {
                            SmsManager.getDefault().sendTextMessage(dest, null, msg, null, null);
                            toast("SMS reminder sent.");
                        } catch (Exception e) {
                            toast("Could not send SMS reminder.");
                        }
                    }
                }
            }

            finish();
        });


        // Bottom navigation wiring
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        if (bottomNav != null) {
            // Highlight Home; listener handles taps to navigate
            bottomNav.setSelectedItemId(R.id.nav_home);
            bottomNav.setOnItemSelectedListener(item -> {
                if (item.getItemId() == R.id.nav_home) {
                    startActivity(new android.content.Intent(this, EventsActivity.class)
                            .putExtra("username", username));
                    return true;
                } else if (item.getItemId() == R.id.nav_settings) {
                    startActivity(new android.content.Intent(this, SettingsActivity.class)
                            .putExtra("username", username));
                    return true;
                }
                return false;
            });
        }
        updateChosen();
        updateSmsLabel();
    }

    @Override protected void onResume() {
        super.onResume();
        updateSmsLabel(); // refresh SMS permission label when returning to screen
    }

    /** Returns trimmed text or null for empty fields (so DB stores NULL vs empty string). */
    private String safeText(EditText et) { return et.getText()==null ? null : et.getText().toString().trim(); }

    /** Updates the "Selected:" label with the current calendar date/time. */
    private void updateChosen() {
        Date d = cal.getTime();
        String when = java.text.DateFormat.getDateTimeInstance(
                java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(d);
        tvChosen.setText("Selected: " + when);
    }

    /** Reflects current SEND_SMS permission state beside the toggle. */
    private void updateSmsLabel() {
        tvSmsPerm.setText(SmsPermissionHelper.hasSmsPermission(this) ? "Permission: On" : "Permission: Off");
    }

    /** Returns true if the provided millis corresponds to "today" in device timezone. */
    private boolean isToday(long when) {
        Calendar a = Calendar.getInstance(); a.setTimeInMillis(when);
        Calendar b = Calendar.getInstance();
        return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)
                && a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);
    }

    /** Small helper to show short toasts. */
    private void toast(String s){
        android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show();
    }
}
