package com.example.eventtracker_jaredbatin;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Settings screen for managing SEND_SMS permission.
 * - Shows current permission state and a button to request/modify it.
 * - Provides a shortcut to system App Settings.
 * - BottomNavigationView routes between Home and Settings.
 */
public class SettingsActivity extends AppCompatActivity {
    private static final int REQ_SMS = 42;   // request code for runtime permission
    private String username;                 // current owner passed via Intent
    private TextView tvSmsStatus;            // "SMS Permission: On/Off"
    private Button btnManage;                // Request/Manage permission

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        username = getIntent().getStringExtra("username");

        // Bind views
        tvSmsStatus = findViewById(R.id.tvSmsStatus);
        btnManage = findViewById(R.id.btnManageSms);
        Button btnOpenAppSettings = findViewById(R.id.btnOpenAppSettings);

        // Primary button: if permission not granted -> request; else -> open system settings
        btnManage.setOnClickListener(v -> {
            if (!SmsPermissionHelper.hasSmsPermission(this)) {
                SmsPermissionHelper.requestSmsPermission(this, REQ_SMS);
            } else {
                // Already granted, open system settings if they want to manage it
                SmsPermissionHelper.openAppSettings(this);
            }
        });

        // Secondary button: always open system App Settings page
        btnOpenAppSettings.setOnClickListener(v -> SmsPermissionHelper.openAppSettings(this));

        // Bottom nav routing (highlight Settings)
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        if (bottomNav != null) {
            bottomNav.setOnItemSelectedListener(item -> {
                if (item.getItemId() == R.id.nav_home) {
                    startActivity(new Intent(this, EventsActivity.class)
                            .putExtra("username", username));
                    return true;
                } else if (item.getItemId() == R.id.nav_settings) {
                    return true; // already here
                }
                return false;
            });
            bottomNav.setSelectedItemId(R.id.nav_settings);
        }

        updateStatus(); // initial state
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus(); // reflect any changes after returning from system Settings
    }

    /** Updates UI labels/buttons to reflect current SEND_SMS permission state. */
    private void updateStatus() {
        boolean on = SmsPermissionHelper.hasSmsPermission(this);
        tvSmsStatus.setText(on ? "SMS Permission: On" : "SMS Permission: Off");
        btnManage.setText(on ? "Manage SMS Permission" : "Enable SMS Permission");
    }

    /**
     * Receives the result of requestPermissions; we don't need to parse the arrays here,
     * just refresh UI to show the new state.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        updateStatus();
    }
}
