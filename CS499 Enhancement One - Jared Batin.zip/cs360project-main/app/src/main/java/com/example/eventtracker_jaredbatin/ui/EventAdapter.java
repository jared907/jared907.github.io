package com.example.eventtracker_jaredbatin.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventtracker_jaredbatin.R;
import com.example.eventtracker_jaredbatin.data.Repo;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/**
 * RecyclerView adapter for the events list.
 * - Binds Repo.EventRow to item_event.xml
 * - Shows compact extra info (description/location/notes) and hides empty lines
 * - Emits edit/delete callbacks to the host Activity
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.VH> {
    /** Callback contract implemented by the hosting screen (EventsActivity). */
    public interface Callbacks { void onDelete(Repo.EventRow row); void onEdit(Repo.EventRow row); }

    private List<Repo.EventRow> data;       // current dataset displayed by the list
    private final Callbacks callbacks;      // edit/delete handlers provided by host

    public EventAdapter(List<Repo.EventRow> data, Callbacks cb) { this.data = data; this.callbacks = cb; }

    /** Replaces the list data and refreshes the UI. */
    public void setData(List<Repo.EventRow> d){ this.data = d; notifyDataSetChanged(); }

    /** Simple ViewHolder that caches the item's child views. */
    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDate, tvDescription, tvLocation, tvNotes;
        Button btnDelete, btnEdit;
        VH(@NonNull View v){ super(v);
            tvTitle = v.findViewById(R.id.tvTitle);
            tvDate  = v.findViewById(R.id.tvDate);
            tvDescription = v.findViewById(R.id.tvDescription);
            tvLocation = v.findViewById(R.id.tvLocation);
            tvNotes = v.findViewById(R.id.tvNotes);
            btnDelete = v.findViewById(R.id.btnDelete);
            btnEdit = v.findViewById(R.id.btnEdit);
        }
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate a new card view for each row
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        // Bind the row model to the views
        Repo.EventRow row = data.get(pos);
        h.tvTitle.setText(row.title);
        h.tvDate.setText(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                .format(new Date(row.timeMillis)));

        // Conditionally show/hide optional lines for compactness
        setTextOrGone(h.tvDescription, row.description);
        setTextOrGone(h.tvLocation, row.location);
        setTextOrGone(h.tvNotes, row.notes);

        // Wire action buttons to host callbacks
        h.btnDelete.setOnClickListener(v -> callbacks.onDelete(row));
        h.btnEdit.setOnClickListener(v -> callbacks.onEdit(row));
    }

    @Override public int getItemCount() { return data==null?0:data.size(); }

    /**
     * Utility: show a TextView only if it has non-empty text; otherwise hide it.
     * Also requests layout on parent so hidden rows don't leave visual gaps.
     */
    private static void setTextOrGone(TextView tv, String s){
        if (s == null || s.trim().isEmpty()) tv.setVisibility(View.GONE);
        else { tv.setText(s.trim()); tv.setVisibility(View.VISIBLE); }
        View parent = (View) tv.getParent();
        if (parent != null) parent.requestLayout();
    }
}
