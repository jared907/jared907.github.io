package com.example.eventtracker_jaredbatin.data;

import android.util.Base64;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Minimal password hashing helper (PBKDF2) for CS499 enhancement.
 * Stores as: pbkdf2$<iterations>$<saltBase64>$<hashBase64>
 */
public final class PasswordUtil {

    private static final String ALGO = "PBKDF2WithHmacSHA256";
    private static final int ITERATIONS = 120_000;
    private static final int SALT_BYTES = 16;
    private static final int KEY_BITS = 256;

    private PasswordUtil() {}

    public static String hashPassword(String password) {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] hash = pbkdf2(password, salt, ITERATIONS);

        String saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP);
        String hashB64 = Base64.encodeToString(hash, Base64.NO_WRAP);

        return "pbkdf2$" + ITERATIONS + "$" + saltB64 + "$" + hashB64;
    }

    public static boolean verifyPassword(String password, String stored) {
        if (stored == null) return false;

        // Expected format: pbkdf2$iters$salt$hash
        String[] parts = stored.split("\\$");
        if (parts.length != 4) return false;
        if (!"pbkdf2".equals(parts[0])) return false;

        int iters;
        try {
            iters = Integer.parseInt(parts[1]);
        } catch (NumberFormatException e) {
            return false;
        }

        byte[] salt = Base64.decode(parts[2], Base64.NO_WRAP);
        byte[] expectedHash = Base64.decode(parts[3], Base64.NO_WRAP);

        byte[] actualHash = pbkdf2(password, salt, iters);
        return constantTimeEquals(expectedHash, actualHash);
    }

    private static byte[] pbkdf2(String password, byte[] salt, int iterations) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, KEY_BITS);
        try {
            SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGO);
            return skf.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            // If this ever fails, safest behavior is to not allow auth.
            throw new IllegalStateException("Password hashing unavailable", e);
        } finally {
            spec.clearPassword();
        }
    }

    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a == null || b == null) return false;
        if (a.length != b.length) return false;
        int result = 0;
        for (int i = 0; i < a.length; i++) result |= (a[i] ^ b[i]);
        return result == 0;
    }
}
