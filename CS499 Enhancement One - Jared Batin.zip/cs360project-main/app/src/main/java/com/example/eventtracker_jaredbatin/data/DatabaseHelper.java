package com.example.eventtracker_jaredbatin.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Central SQLite helper for creating and upgrading the app database.
 * - DB v1: users + events (title, time)
 * - DB v2: adds owner column to events
 * - DB v3: adds description, location, notes, notify_app, notify_sms
 *
 * NOTE: Keep all schema constants in this class to avoid string duplication.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "eventtracker.db";
    private static final int DB_VERSION = 3; // bump when schema changes

    // USERS table + columns
    public static final String T_USERS = "users";
    public static final String COL_U_ID = "_id";
    public static final String COL_U_NAME = "username";
    public static final String COL_U_PASS = "password";
    public static final String COL_U_PHONE = "phone";

    // EVENTS table + baseline columns
    public static final String T_EVENTS = "events";
    public static final String COL_E_ID = "_id";
    public static final String COL_E_TITLE = "title";
    public static final String COL_E_TIME = "timeMillis";
    public static final String COL_E_OWNER = "owner";

    // EVENTS extra columns (added in v3)
    public static final String COL_E_DESC = "description";
    public static final String COL_E_LOCATION = "location";
    public static final String COL_E_NOTES = "notes";
    public static final String COL_E_NOTIFY_APP = "notify_app";
    public static final String COL_E_NOTIFY_SMS = "notify_sms";

    public DatabaseHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    /**
     * Called on first run. Creates all tables with the latest schema.
     * If you change schema, also update onUpgrade with safe ALTERs.
     */
    @Override public void onCreate(SQLiteDatabase db) {
        // Users: simple auth + optional phone for SMS
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                COL_U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_U_NAME + " TEXT UNIQUE NOT NULL, " +
                COL_U_PASS + " TEXT NOT NULL, " +
                COL_U_PHONE + " TEXT)");

        // Events: core + v3 extras, defaults keep old rows compatible
        db.execSQL("CREATE TABLE " + T_EVENTS + " (" +
                COL_E_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_E_TITLE + " TEXT NOT NULL, " +
                COL_E_TIME + " INTEGER NOT NULL, " +
                COL_E_OWNER + " TEXT NOT NULL, " +     // v2 required in latest schema
                COL_E_DESC + " TEXT, " +               // v3
                COL_E_LOCATION + " TEXT, " +           // v3
                COL_E_NOTES + " TEXT, " +              // v3
                COL_E_NOTIFY_APP + " INTEGER DEFAULT 0, " + // v3
                COL_E_NOTIFY_SMS + " INTEGER DEFAULT 0" +   // v3
                ")");
    }

    /**
     * Handles incremental upgrades from older versions.
     * Use guarded ALTERs to avoid crashes if a column already exists.
     */
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // v2: add owner to events (existing rows get empty string)
        if (oldV < 2) {
            try {
                db.execSQL("ALTER TABLE " + T_EVENTS + " ADD COLUMN " + COL_E_OWNER + " TEXT");
                db.execSQL("UPDATE " + T_EVENTS + " SET " + COL_E_OWNER + "='' WHERE " + COL_E_OWNER + " IS NULL");
            } catch (Exception ignored) {} // tolerate re-run or vendor-specific SQL differences
        }
        // v3: add optional extras + notify flags with safe defaults
        if (oldV < 3) {
            try { db.execSQL("ALTER TABLE " + T_EVENTS + " ADD COLUMN " + COL_E_DESC + " TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE " + T_EVENTS + " ADD COLUMN " + COL_E_LOCATION + " TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE " + T_EVENTS + " ADD COLUMN " + COL_E_NOTES + " TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE " + T_EVENTS + " ADD COLUMN " + COL_E_NOTIFY_APP + " INTEGER DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE " + T_EVENTS + " ADD COLUMN " + COL_E_NOTIFY_SMS + " INTEGER DEFAULT 0"); } catch (Exception ignored) {}
        }
    }
}
