package com.example.eventtracker_jaredbatin;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtracker_jaredbatin.data.Repo;

/**
 * Simple login/registration screen.
 * - Sign in checks credentials against SQLite via Repo.
 * - Create Account inserts a new user row (username must be unique).
 * - On success, navigates to EventsActivity passing the username as owner.
 */
public class LoginActivity extends AppCompatActivity {
    private TextInputEditText etUsername, etPassword, etPhone;
    private Button btnSignIn, btnCreateAccount;
    private Repo repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (getSupportActionBar() != null)
            getSupportActionBar().hide();

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etPhone = findViewById(R.id.etPhone);

        btnSignIn = findViewById(R.id.btnSignIn);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        repo = Repo.getInstance(this);

        btnSignIn.setOnClickListener(v -> {
            String username = etUsername.getText() == null ? "" : etUsername.getText().toString().trim();
            String password = etPassword.getText() == null ? "" : etPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Enter username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = repo.checkLogin(username, password);
            if (ok) {
                Intent intent = new Intent(LoginActivity.this, EventsActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            } else {
                Toast.makeText(LoginActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
            }
        });

        btnCreateAccount.setOnClickListener(v -> {
            String username = etUsername.getText() == null ? "" : etUsername.getText().toString().trim();
            String password = etPassword.getText() == null ? "" : etPassword.getText().toString();
            String phone = etPhone.getText() == null ? "" : etPhone.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Username and password are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = repo.createUser(username, password, phone);
            if (created) {
                Toast.makeText(LoginActivity.this, "Account created. Please sign in.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Account not created. Username may already exist.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
