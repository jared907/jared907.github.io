# cs330project

## Reflection

### How do I approach designing software?
- **What new design skills has your work on the project helped you to craft?**  
  I learned to balance realism with performance by composing the scene from simple shapes and reusing materials. I also improved at choosing UV tiling and basic lighting that maintains clarity at typical camera distances.

- **What design process did you follow for your project work?**  
  I gathered resources, created out the Torii Gate with shapes, then iterated on proportions, materials, and a small light setup. Each pass focused on the readability of the silhouette and the feel of the wood and water surfaces.

- **How could tactics from your design approach be applied in future work?**  
  Starting with a minimal, reusable asset set and centralizing materials/lights keeps changes low-risk and fast. I can reuse this approach for UI scenes, simulations, or future graphics projects that need a clear structure and a consistent look.

### How do I approach developing programs?
- **What new development strategies did you use while working on your 3D scene?**  
  I separated responsibilities (camera/input, lighting/material helpers, and render composition) so changes stayed localized. I also used a one-time mesh/material setup to avoid redundant work per frame.

- **How did iteration factor into your development?**  
  I made small, testable tweaks like camera speed, light intensity/color, and material parameters, and then reviewed the result in real time. This tight loop helped catch issues early without large refactors.

- **How has your approach to developing code evolved throughout the milestones, which led you to the project’s completion?**  
  Every milestone works on specific parts of the spene, resulting in more clearer modules and naming. Doing so reduced bugs and made the final assembly straightforward. The milestones pushed me to plan ahead and document choices as I went.

### How can computer science help me in reaching my goals?
- **How do computational graphics and visualizations give you new knowledge and skills that can be applied in your future educational pathway?**  
  Building the scene reinforced transformations, lighting models, and camera control foundations that transfer to later courses in graphics, interactive systems, simulations, and much more.
