package com.example.eventtracker_jaredbatin.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Thin repository over SQLite that encapsulates:
 * - User auth: create + credential check + phone retrieval
 * - Event CRUD: add/update/delete/read
 *
 * Design notes:
 * - Uses parameterized query APIs (db.query/update/delete) to avoid SQL injection.
 * - Always closes cursors to prevent leaks.
 * - Overloaded add/update for events: simple (title/time) and full (with extras).
 * - Mapping from Cursor -> EventRow is centralized in getAllEvents.
 */
public class Repo {
    private final DatabaseHelper helper;
    public Repo(Context ctx) { helper = new DatabaseHelper(ctx); }

    // ---------- USERS ----------

    /**
     * Creates a new user row. Username is trimmed and unique.
     * @return true if row inserted, false if duplicate or error.
     */
    public boolean createUser(String username, String password, String phone) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_U_NAME, username.trim());
        cv.put(DatabaseHelper.COL_U_PASS, password);
        cv.put(DatabaseHelper.COL_U_PHONE, phone);
        long id = -1;
        try { id = db.insertOrThrow(DatabaseHelper.T_USERS, null, cv); } catch (Exception ignored) {}
        return id != -1;
    }

    /**
     * Checks if (username,password) exists.
     * @return true if credentials match a row.
     */
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.T_USERS, new String[]{DatabaseHelper.COL_U_ID},
                DatabaseHelper.COL_U_NAME + "=? AND " + DatabaseHelper.COL_U_PASS + "=?",
                new String[]{username.trim(), password}, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    /**
     * Fetches the user's phone number (for SMS reminders).
     * @return phone or null if not found.
     */
    public String getUserPhone(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.T_USERS, new String[]{DatabaseHelper.COL_U_PHONE},
                DatabaseHelper.COL_U_NAME + "=?", new String[]{username.trim()},
                null, null, null);
        String phone = null;
        if (c.moveToFirst()) phone = c.getString(0);
        c.close();
        return phone;
    }

    // ---------- EVENTS ----------

    /**
     * Adds a basic event (title/time/owner only).
     * Delegates to the full overload with null/false defaults.
     */
    public long addEvent(String owner, String title, long timeMillis) {
        return addEvent(owner, title, timeMillis, null, null, null, false, false);
    }

    /**
     * Adds a full event with optional extras.
     * All extras are nullable; booleans stored as 0/1.
     * @return new row ID or -1 on error.
     */
    public long addEvent(String owner, String title, long timeMillis,
                         String description, String location, String notes,
                         boolean notifyApp, boolean notifySms) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_E_TITLE, title == null ? "" : title.trim());
        cv.put(DatabaseHelper.COL_E_TIME, timeMillis);
        cv.put(DatabaseHelper.COL_E_OWNER, owner == null ? "" : owner.trim());
        cv.put(DatabaseHelper.COL_E_DESC, description);
        cv.put(DatabaseHelper.COL_E_LOCATION, location);
        cv.put(DatabaseHelper.COL_E_NOTES, notes);
        cv.put(DatabaseHelper.COL_E_NOTIFY_APP, notifyApp ? 1 : 0);
        cv.put(DatabaseHelper.COL_E_NOTIFY_SMS, notifySms ? 1 : 0);
        long id = -1;
        try { id = db.insertOrThrow(DatabaseHelper.T_EVENTS, null, cv); } catch (Exception ignored) {}
        return id;
    }

    /**
     * Updates core fields for an event.
     * Owner is part of the WHERE to scope edits to the current user.
     */
    public boolean updateEvent(long id, String owner, String title, long timeMillis) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_E_TITLE, title.trim());
        cv.put(DatabaseHelper.COL_E_TIME, timeMillis);
        int rows = db.update(DatabaseHelper.T_EVENTS, cv,
                DatabaseHelper.COL_E_ID + "=? AND " + DatabaseHelper.COL_E_OWNER + "=?",
                new String[]{String.valueOf(id), owner});
        return rows > 0;
    }

    /**
     * Updates all fields for an event, including extras.
     * Returns true if one or more rows changed.
     */
    public boolean updateEvent(long id, String owner, String title, long timeMillis,
                               String description, String location, String notes,
                               boolean notifyApp, boolean notifySms) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_E_TITLE, title == null ? "" : title.trim());
        cv.put(DatabaseHelper.COL_E_TIME, timeMillis);
        cv.put(DatabaseHelper.COL_E_DESC, description);
        cv.put(DatabaseHelper.COL_E_LOCATION, location);
        cv.put(DatabaseHelper.COL_E_NOTES, notes);
        cv.put(DatabaseHelper.COL_E_NOTIFY_APP, notifyApp ? 1 : 0);
        cv.put(DatabaseHelper.COL_E_NOTIFY_SMS, notifySms ? 1 : 0);
        int rows = db.update(DatabaseHelper.T_EVENTS, cv,
                DatabaseHelper.COL_E_ID + "=? AND " + DatabaseHelper.COL_E_OWNER + "=?",
                new String[]{String.valueOf(id), owner});
        return rows > 0;
    }

    /**
     * Deletes an event scoped to the owner.
     * @return true if a row was removed.
     */
    public boolean deleteEvent(long id, String owner) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int rows = db.delete(DatabaseHelper.T_EVENTS,
                DatabaseHelper.COL_E_ID + "=? AND " + DatabaseHelper.COL_E_OWNER + "=?",
                new String[]{String.valueOf(id), owner});
        return rows > 0;
    }

    /**
     * In-memory model for an event row. Nullable strings for optional fields.
     */
    public static class EventRow {
        public long id;
        public String title;
        public long timeMillis;
        public String owner;

        public String description;
        public String location;
        public String notes;
        public boolean notifyApp;
        public boolean notifySms;
    }

    /**
     * Returns all events for the given owner ordered by time ascending.
     * Maps each cursor row to EventRow; optional columns read via getColumnIndex.
     */
    public List<EventRow> getAllEvents(String owner) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.T_EVENTS, null,
                DatabaseHelper.COL_E_OWNER + "=?", new String[]{owner},
                null, null, DatabaseHelper.COL_E_TIME + " ASC");
        List<EventRow> out = new ArrayList<>();
        while (c.moveToNext()) {
            EventRow e = new EventRow();
            // Required columns (throw if missing = schema mismatch)
            e.id = c.getLong(c.getColumnIndexOrThrow(DatabaseHelper.COL_E_ID));
            e.title = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COL_E_TITLE));
            e.timeMillis = c.getLong(c.getColumnIndexOrThrow(DatabaseHelper.COL_E_TIME));
            e.owner = owner;

            // Optional columns (use getColumnIndex to tolerate older rows)
            int iDesc = c.getColumnIndex(DatabaseHelper.COL_E_DESC);
            int iLoc  = c.getColumnIndex(DatabaseHelper.COL_E_LOCATION);
            int iNote = c.getColumnIndex(DatabaseHelper.COL_E_NOTES);
            int iApp  = c.getColumnIndex(DatabaseHelper.COL_E_NOTIFY_APP);
            int iSms  = c.getColumnIndex(DatabaseHelper.COL_E_NOTIFY_SMS);
            e.description = iDesc >= 0 ? c.getString(iDesc) : null;
            e.location    = iLoc  >= 0 ? c.getString(iLoc)  : null;
            e.notes       = iNote >= 0 ? c.getString(iNote) : null;
            e.notifyApp   = iApp  >= 0 && c.getInt(iApp) == 1;
            e.notifySms   = iSms  >= 0 && c.getInt(iSms) == 1;

            out.add(e);
        }
        c.close(); // always close the cursor
        return out;
    }
}
