package com.example.eventtracker_jaredbatin;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtracker_jaredbatin.data.Repo;

/**
 * Simple login/registration screen.
 * - Sign in checks credentials against SQLite via Repo.
 * - Create Account inserts a new user row (username must be unique).
 * - On success, navigates to EventsActivity passing the username as owner.
 */
public class LoginActivity extends AppCompatActivity {
    private TextInputEditText etUsername, etPassword;
    private Button btnSignIn, btnCreateAccount;
    private Repo repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (getSupportActionBar() != null) getSupportActionBar().hide(); // cleaner full-screen login

        // Bind UI elements
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnSignIn  = findViewById(R.id.btnSignIn);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        repo = new Repo(this); // data access layer

        // Attempt sign-in: validate non-empty, check DB, then route to Events
        btnSignIn.setOnClickListener(v -> {
            String u = text(etUsername), p = text(etPassword);
            if (u.isEmpty() || p.isEmpty()) { toast("Enter username and password"); return; }
            if (repo.checkLogin(u, p)) {
                startActivity(new Intent(this, EventsActivity.class)
                        .putExtra("username", u));
            } else {
                toast("Invalid login");
            }
        });

        // Create account: inserts into users table; informs user on success/failure
        btnCreateAccount.setOnClickListener(v -> {
            String u = text(etUsername), p = text(etPassword);
            if (u.isEmpty() || p.isEmpty()) { toast("Enter username and password"); return; }
            boolean ok = repo.createUser(u, p, null);
            toast(ok ? "Account created. Sign in now." : "Username already exists");
        });
    }

    /** Safely extracts trimmed text from a TextInputEditText. */
    private static String text(TextInputEditText e){ return e.getText()==null?"":e.getText().toString().trim(); }
    /** Convenience toast helper. */
    private void toast(String msg){ android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show(); }
}
