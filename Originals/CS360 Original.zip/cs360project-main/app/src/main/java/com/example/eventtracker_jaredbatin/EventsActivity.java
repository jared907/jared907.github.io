package com.example.eventtracker_jaredbatin;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eventtracker_jaredbatin.data.Repo;
import com.example.eventtracker_jaredbatin.ui.EventAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Home screen:
 * - Lists all events for the current user
 * - Allows add / edit / delete
 * - Edit opens a dialog matching the "add" fields and persists updates via Repo
 */
public class EventsActivity extends AppCompatActivity implements EventAdapter.Callbacks {
    private Repo repo;                 // data access
    private EventAdapter adapter;      // RecyclerView adapter
    private String username;           // current user (owner of events)

    // Shared formatter for dialog "Chosen" label
    private final DateFormat dateFmt =
            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        repo = new Repo(this);
        username = getIntent().getStringExtra("username");

        // RecyclerView + adapter
        RecyclerView rv = findViewById(R.id.rvEvents);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(repo.getAllEvents(username), this);
        rv.setAdapter(adapter);

        // Header title
        TextView tvHeader = findViewById(R.id.tvHeader);
        tvHeader.setText("Upcoming Events");

        // Navigate to Add screen
        Button btnAdd = findViewById(R.id.btnAddEvent);
        btnAdd.setOnClickListener(v ->
                startActivity(new Intent(this, AddEventActivity.class)
                        .putExtra("username", username)));

        // Bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        if (bottomNav != null) {
            bottomNav.setOnItemSelectedListener(item -> {
                if (item.getItemId() == R.id.nav_home) {
                    return true; // already here
                } else if (item.getItemId() == R.id.nav_settings) {
                    startActivity(new Intent(this, SettingsActivity.class)
                            .putExtra("username", username));
                    return true;
                }
                return false;
            });
            bottomNav.setSelectedItemId(R.id.nav_home);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Refresh list when returning from Add/Edit
        if (adapter != null) adapter.setData(repo.getAllEvents(username));
    }

    /** Delete handler from adapter. */
    @Override public void onDelete(Repo.EventRow row) {
        repo.deleteEvent(row.id, username);
        adapter.setData(repo.getAllEvents(username));
    }

    /**
     * Edit handler from adapter:
     * Builds a dialog view that mirrors AddEventActivity fields,
     * pre-fills from the row, lets user pick date/time, and saves.
     */
    @Override public void onEdit(Repo.EventRow row) {
        final Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(row.timeMillis);

        // Inflate dialog layout with the same widgets as on Add screen
        View v = getLayoutInflater().inflate(R.layout.dialog_edit_event, null, false);

        EditText etTitle = v.findViewById(R.id.etTitle);
        EditText etDescription = v.findViewById(R.id.etDescription);
        EditText etLocation = v.findViewById(R.id.etLocation);
        EditText etNotes = v.findViewById(R.id.etNotes);
        Switch swAppNotification = v.findViewById(R.id.swAppNotification);
        Switch swSms = v.findViewById(R.id.swSms);
        TextView tvSmsPermStatus = v.findViewById(R.id.tvSmsPermStatus);
        Button btnPickDate = v.findViewById(R.id.btnPickDate);
        Button btnPickTime = v.findViewById(R.id.btnPickTime);
        TextView tvChosen = v.findViewById(R.id.tvChosen);

        // Prefill (title/time persisted; other fields may be null)
        etTitle.setText(row.title);
        if (row.description != null) etDescription.setText(row.description);
        if (row.location != null) etLocation.setText(row.location);
        if (row.notes != null) etNotes.setText(row.notes);
        swAppNotification.setChecked(row.notifyApp);
        swSms.setChecked(row.notifySms);
        tvChosen.setText(dateFmt.format(new Date(cal.getTimeInMillis())));

        // Show current SEND_SMS permission state (for info only)
        boolean hasSmsPerm = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        tvSmsPermStatus.setText("Permission: " + (hasSmsPerm ? "On" : "Off"));

        // Date picker -> updates calendar + summary
        btnPickDate.setOnClickListener(v1 -> new DatePickerDialog(
                this,
                (dp, y, m, d) -> {
                    cal.set(Calendar.YEAR, y);
                    cal.set(Calendar.MONTH, m);
                    cal.set(Calendar.DAY_OF_MONTH, d);
                    tvChosen.setText(dateFmt.format(cal.getTime()));
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
        ).show());

        // Time picker -> updates calendar + summary
        btnPickTime.setOnClickListener(v12 -> new TimePickerDialog(
                this,
                (tp, hh, mm) -> {
                    cal.set(Calendar.HOUR_OF_DAY, hh);
                    cal.set(Calendar.MINUTE, mm);
                    cal.set(Calendar.SECOND, 0);
                    cal.set(Calendar.MILLISECOND, 0);
                    tvChosen.setText(dateFmt.format(cal.getTime()));
                },
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                android.text.format.DateFormat.is24HourFormat(this)
        ).show());

        // Save -> persist updates via Repo, then refresh list
        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> {
                    String newTitle = etTitle.getText() == null ? "" : etTitle.getText().toString().trim();
                    repo.updateEvent(
                            row.id,
                            username,
                            newTitle,
                            cal.getTimeInMillis(),
                            safeText(etDescription),
                            safeText(etLocation),
                            safeText(etNotes),
                            swAppNotification.isChecked(),
                            swSms.isChecked()
                    );
                    adapter.setData(repo.getAllEvents(username));
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Returns trimmed text or null for empty fields, mirroring AddEventActivity helper. */
    private String safeText(EditText et) { return et.getText()==null ? null : et.getText().toString().trim(); }
}
