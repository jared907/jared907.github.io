"""animal_shelter.py

Database access layer for the Grazioso Salvare dashboard.

CS 499 (Databases) Enhancement Goals
- Remove hard-coded connection settings by supporting environment-based configuration.
- Add practical indexes for the most common dashboard filters.
- Improve read operations with optional projection, sorting, and limiting results.

Environment variables (preferred)
- MONGO_URI: Full connection string. Example: mongodb://user:pass@localhost:27017/?authSource=admin
- MONGO_HOST: Hostname (default: localhost)
- MONGO_PORT: Port (default: 27017)
- MONGO_DB: Database name (default: AAC)
- MONGO_COLLECTION: Collection name (default: animals)
- MONGO_AUTH_DB: Auth database (default: admin)
- MONGO_USER / MONGO_USERNAME: Username (optional)
- MONGO_PASS / MONGO_PASSWORD: Password (optional)

Notes
- If MONGO_URI is set, it overrides host/port/user/pass settings.
- If no credentials are provided, the client connects without authentication.
"""

from __future__ import annotations

import os
import logging
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote_plus

from pymongo import MongoClient, ASCENDING
from pymongo.errors import PyMongoError

logger = logging.getLogger(__name__)


class AnimalShelter:
    """CRUD wrapper for the AAC animals collection."""

    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        db_name: Optional[str] = None,
        collection_name: Optional[str] = None,
        auth_db: Optional[str] = None,
        mongo_uri: Optional[str] = None,
    ):
        # ----- configuration -----
        mongo_uri = mongo_uri or os.getenv("MONGO_URI")

        host = host or os.getenv("MONGO_HOST", "localhost")
        port = int(port or os.getenv("MONGO_PORT", "27017"))
        db_name = db_name or os.getenv("MONGO_DB", "AAC")
        collection_name = collection_name or os.getenv("MONGO_COLLECTION", "animals")
        auth_db = auth_db or os.getenv("MONGO_AUTH_DB", "admin")

        # Credentials can be passed in (not recommended for committed code) OR set via env vars.
        username = username or os.getenv("MONGO_USER") or os.getenv("MONGO_USERNAME")
        password = password or os.getenv("MONGO_PASS") or os.getenv("MONGO_PASSWORD")

        # Build a URI if one wasn't provided.
        if not mongo_uri:
            if username and password:
                u = quote_plus(username)
                p = quote_plus(password)
                mongo_uri = f"mongodb://{u}:{p}@{host}:{port}/?authSource={auth_db}"
            else:
                mongo_uri = f"mongodb://{host}:{port}/"

        # ----- connect -----
        self.client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

        # Validate connection early (helps catch misconfiguration quickly).
        try:
            self.client.admin.command("ping")
        except Exception as ex:  # noqa: BLE001
            logger.warning("MongoDB ping failed. Check connection settings. %s", ex)

        # Performance: create lightweight indexes used by common dashboard filters.
        self._ensure_indexes()

    # ---------- Internal helpers ----------

    def _ensure_indexes(self) -> None:
        """Create indexes safely (no-op if they already exist).

        These indexes align to the filters commonly used in the dashboard queries.
        """
        try:
            self.collection.create_index([("animal_type", ASCENDING)], name="idx_animal_type")
            self.collection.create_index([("breed", ASCENDING)], name="idx_breed")
            self.collection.create_index([("sex_upon_outcome", ASCENDING)], name="idx_sex_upon_outcome")
            self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)], name="idx_age_weeks")

            # Compound index helps multi-filter queries (prefixes still benefit).
            self.collection.create_index(
                [
                    ("animal_type", ASCENDING),
                    ("breed", ASCENDING),
                    ("sex_upon_outcome", ASCENDING),
                    ("age_upon_outcome_in_weeks", ASCENDING),
                ],
                name="idx_dash_filters",
            )
        except PyMongoError as ex:
            # Index creation can fail if user lacks permissions; the app should still run.
            logger.warning("Unable to create indexes (permission/config issue). %s", ex)

    @staticmethod
    def _require_dict(value: Any, name: str) -> Dict[str, Any]:
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise TypeError(f"{name} must be a dict")
        return value

    # ---------- CRUD ----------

    def create(self, data: Dict[str, Any]) -> bool:
        """Insert a single document."""
        data = self._require_dict(data, "data")
        if not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as ex:
            logger.warning("Insert failed: %s", ex)
            return False

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[Sequence[Tuple[str, int]]] = None,
        limit: int = 0,
    ) -> List[Dict[str, Any]]:
        """Read documents with optional projection/sort/limit.

        Args:
            query: Mongo filter dict. Defaults to {}.
            projection: Field include/exclude dict. Example: {"_id": 0, "breed": 1}
            sort: Sequence of (field, direction) tuples. Example: [("datetime", 1)]
            limit: Max docs to return (0 = no limit).
        """
        query = self._require_dict(query, "query")
        if projection is not None and not isinstance(projection, dict):
            raise TypeError("projection must be a dict or None")

        try:
            cursor = self.collection.find(query, projection)
            if sort:
                cursor = cursor.sort(list(sort))
            if limit and int(limit) > 0:
                cursor = cursor.limit(int(limit))
            return list(cursor)
        except PyMongoError as ex:
            logger.warning("Read failed: %s", ex)
            return []

    def update(self, query: Dict[str, Any], new_data: Dict[str, Any]) -> int:
        """Update one or more documents.

        Returns:
            Number of documents modified.
        """
        query = self._require_dict(query, "query")
        new_data = self._require_dict(new_data, "new_data")
        if not query or not new_data:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_data})
            return int(result.modified_count)
        except PyMongoError as ex:
            logger.warning("Update failed: %s", ex)
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """Delete one or more documents.

        Returns:
            Number of documents deleted.
        """
        query = self._require_dict(query, "query")
        if not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return int(result.deleted_count)
        except PyMongoError as ex:
            logger.warning("Delete failed: %s", ex)
            return 0
