///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// flip image vertical
	stbi_set_flip_vertically_on_load(true);
	// load image
	unsigned char* textureImage = stbi_load(filename, &width, &height, &colorChannels, 0);

	// if the image loaded successfully
	if (textureImage)
	{
		std::cout << "Successfully loaded image:" << filename << std::endl;
		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if color channels are 3, generate RGB texture
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, textureImage);
		// if color channels are 4, generate RGBA texture
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureImage);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			glDeleteTextures(1, &textureID);
			textureID = 0;
		}

		// register the loaded texture and associate it with the special tag string
		if (m_loadedTextures >= 16)
		{
			std::cout << "Texture limit reached (16). Skipping: " << filename << std::endl;
			glDeleteTextures(1, &textureID);
			return false;
		}

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_textureSlotByTag[tag] = m_loadedTextures;
		m_loadedTextures++;

		// free image data
		stbi_image_free(textureImage);
		glBindTexture(GL_TEXTURE_2D, 0);
		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;
	// error message from stbi_failure_reason
	std::cout << stbi_failure_reason() << std::endl;
	return false;
}


/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].ID != 0)
		{
			glDeleteTextures(1, &m_textureIDs[i].ID);
			m_textureIDs[i].ID = 0;
			m_textureIDs[i].tag.clear();
		}
	}

	// clear loaded texture data
	m_textureSlotByTag.clear();
	m_loadedTextures = 0;
}


/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	// Fast path: O(1) average lookup using an unordered_map cache
	auto it = m_textureSlotByTag.find(tag);
	if (it != m_textureSlotByTag.end())
	{
		int slot = it->second;
		if (slot >= 0 && slot < m_loadedTextures)
			return m_textureIDs[slot].ID;
	}

	// Fallback: linear scan (also refresh cache)
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag.compare(tag) == 0)
		{
			m_textureSlotByTag[tag] = i;
			return m_textureIDs[i].ID;
		}
	}
	return -1;
}


/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	// Fast path: O(1) average lookup using an unordered_map cache
	auto it = m_textureSlotByTag.find(tag);
	if (it != m_textureSlotByTag.end())
	{
		int slot = it->second;
		if (slot >= 0 && slot < m_loadedTextures)
			return slot;
	}

	// Fallback: linear scan (also refresh cache)
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag.compare(tag) == 0)
		{
			m_textureSlotByTag[tag] = i;
			return i;
		}
	}
	return -1;
}


/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	// Fast path: O(1) average lookup using an unordered_map cache
	auto it = m_materialIndexByTag.find(tag);
	if (it != m_materialIndexByTag.end())
	{
		size_t idx = it->second;
		if (idx < m_objectMaterials.size())
		{
			material = m_objectMaterials[idx];
			return true;
		}
	}

	// Fallback: linear scan (also refresh cache)
	for (size_t index = 0; index < m_objectMaterials.size(); index++)
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			m_materialIndexByTag[tag] = index;
			material = m_objectMaterials[index];
			return true;
		}
	}
	return false;
}


/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	CreateGLTexture("textures/red.jpg", "red");
	CreateGLTexture("textures/woodgrain.jpg", "woodgrain");
	CreateGLTexture("textures/water.jpg", "water");
	CreateGLTexture("textures/roof.jpg", "roof");
	CreateGLTexture("textures/grass.jpg", "grass");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Make the method safe to call more than once
	m_objectMaterials.clear();
	m_materialIndexByTag.clear();
	// Wood material
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 1.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// Water material
	OBJECT_MATERIAL waterMaterial;
	waterMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	waterMaterial.ambientStrength = 0.3f;
	waterMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	waterMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	waterMaterial.shininess = 100.0f;
	waterMaterial.tag = "water";
	m_objectMaterials.push_back(waterMaterial);

	// Roof material
	OBJECT_MATERIAL roofMaterial;
	roofMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	roofMaterial.ambientStrength = 0.1f;
	roofMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	roofMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	roofMaterial.shininess = 10.0f;
	roofMaterial.tag = "roof";
	m_objectMaterials.push_back(roofMaterial);

	// Grass material
	OBJECT_MATERIAL grassMaterial;
	grassMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	grassMaterial.ambientStrength = 0.2f;
	grassMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	grassMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	grassMaterial.shininess =1.0f;
	grassMaterial.tag = "grass";
	m_objectMaterials.push_back(grassMaterial);

	// Build fast lookup cache for materials (tag -> index)
	for (size_t i = 0; i < m_objectMaterials.size(); i++)
	{
		m_materialIndexByTag[m_objectMaterials[i].tag] = i;
	}

}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Light 1
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[0].position", 0.0f, 10.0f, 10.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.01f, 0.01f, 0.01f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.01f, 0.01f, 0.01f);

	// Light 2 (Yellow Sun)
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[1].position", -10.0f, 30.0f, 30.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.02f, 0.01f, 0.01f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 3.0f, 2.0f, 1.0f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 3.0f, 2.0f, 1.0f);

	// Light 3 (Blue Sky)
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);
	m_pShaderManager->setVec3Value("directionalLight.direction", -10.0f, -10.0f, 10.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.1f, 0.1f, 0.15);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 1.0f, 1.0f, 1.5);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.1f, 0.1f, 0.1f);

	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();
	// load the textures for the 3D scene
	LoadSceneTextures();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 rotation2;
	glm::mat4 translation;
	glm::mat4 model;

	/******************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	/****************************************************************/
	/*                  Ground Plane (water)                        */
	/****************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(100.0f, 1.0f, 100.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("water");
	SetShaderMaterial("water");

	SetTextureUVScale(8.0f, 8.0f); // tile for better scaling of texture

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/
	/*                  MAIN TWO PILLARS                            */
	/****************************************************************/

	/**************************/
	/*  Left cylinder base    */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 6.0f, 1.0f); // tall cylinder

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.5f, 0.0f, 0.0f); // moved to the left

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh(); // tapered cylinder to match Torii Gate shape accurately

	/**************************/
	/*   Left cylinder        */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 5.0f, 0.5f); // tall cylinder that extends above base, no longer tapers

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.5f, 6.0f, 0.0f); // placed above the left tapered cylinder base)

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh(); // regular cylinder, matches Torii Gate shape

	/**************************/
	/*   Left cylinder tip    */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.7f, 0.5f, 0.7f); // very short cylinder

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.5f, 11.0f, 0.0f); // placed above main pillar

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/**************************/
	/* Right cylinder base    */
	/*     -Same code as left */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 6.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.5f, 0.0f, 0.0f); // placed right

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	/**************************/
	/*   Right cylinder       */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 5.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.5f, 6.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/**************************/
	/*   Right cylinder tip   */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.7f, 0.5f, 0.7f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.5f, 11.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/**************************/
	/*   Top crossbeam        */
	/**************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(15.0f, 0.8f, 1.0f); // wide, slightly thick beam

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 11.9f, 0.0f); // sits on top of pillar tips

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	/**************************/
	/*   Second Crossbeam     */
	/**************************/

	scaleXYZ = glm::vec3(13.0f, 0.7f, 0.2f); // slightly smaller than top beam
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 9.5f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("red");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	/**************************/
	/*   Main roof   left     */
	/**************************/

	scaleXYZ = glm::vec3(2.0f, 8.0f, 0.7f); // slightly smaller than top beam
	XrotationDegrees = -90.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = -3.0f;
	positionXYZ = glm::vec3(-4.0f, 12.6f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("roof");
	SetShaderMaterial("roof");
	SetTextureUVScale(4.0f, 1.0f); // tile for better scaling of texture
	m_basicMeshes->DrawPrismMesh();

	/**************************/
	/*   Main roof right     */
	/**************************/

	scaleXYZ = glm::vec3(2.0f, 8.0f, 0.7f); // slightly smaller than top beam
	XrotationDegrees = -90.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 3.0f;
	positionXYZ = glm::vec3(4.0f, 12.6f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("roof");
	SetShaderMaterial("roof");
	SetTextureUVScale(4.0f, 1.0f); // tile for better scaling of texture
	m_basicMeshes->DrawPrismMesh();

	/****************************************************************/
	/*        Four Small Supporting Pillars with Roofs              */
	/****************************************************************/

	// Positions: front-left, front-right, back-left, back-right
	glm::vec3 smallPillarPositions[] = {
		glm::vec3(-4.5f, 0.0f, 3.0f),  // front-left
		glm::vec3(4.5f, 0.0f, 3.0f),  // front-right
		glm::vec3(-4.5f, 0.0f,-3.0f),  // back-left
		glm::vec3(4.5f, 0.0f,-3.0f)   // back-right
	};

	for (int i = 0; i < 4; i++)
	{
		/**************************/
		/* Small Supporting Pillar*/
		/**************************/
		scaleXYZ = glm::vec3(0.4f, 6.0f, 0.4f); 
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(smallPillarPositions[i].x, smallPillarPositions[i].y, smallPillarPositions[i].z);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("red");
		SetShaderMaterial("wood");
		m_basicMeshes->DrawCylinderMesh();

		/**************************/
		/* Small Box under Roof   */
		/**************************/
		scaleXYZ = glm::vec3(1.0f, 0.25f, 1.0f);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(smallPillarPositions[i].x, smallPillarPositions[i].y + 6.0f, smallPillarPositions[i].z);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("red");
		SetShaderMaterial("wood");
		m_basicMeshes->DrawBoxMesh();

		/**************************/
		/* Pyramid Roof           */
		/**************************/
		scaleXYZ = glm::vec3(1.5f, 0.25f, 1.5f);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(smallPillarPositions[i].x, smallPillarPositions[i].y + 6.2f, smallPillarPositions[i].z);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderTexture("roof");
		SetShaderMaterial("roof");
		m_basicMeshes->DrawPyramid4Mesh();
	}

	/****************************************************************/
	/*        Four Small Supporting Crossbeams                      */
	/****************************************************************/
	
	glm::vec3 smallCrossbeamsPositions[] = {
		glm::vec3(4.5f, 5.0f, 0.0f),  // left top
		glm::vec3(4.5f, 2.0f, 0.0f),  // left bottom
		glm::vec3(-4.5f, 5.0f, 0.0f),  // right top
		glm::vec3(-4.5f, 2.0f, 0.0f)   // right bottom
	};

	for (int i = 0; i < 4; i++)
	{
		/**************************/
		/* Small crossbeams       */
		/**************************/
		scaleXYZ = glm::vec3(0.2f, 0.6f, 7.2f);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(smallCrossbeamsPositions[i].x, smallCrossbeamsPositions[i].y, smallCrossbeamsPositions[i].z);

		SetTransformations(
			scaleXYZ, 
			XrotationDegrees, 
			YrotationDegrees, 
			ZrotationDegrees, 
			positionXYZ);

		SetShaderTexture("red");
		SetShaderMaterial("wood");
		m_basicMeshes->DrawBoxMesh();

	}
	/**************************/
	/*   Background Island    */
	/**************************/

	scaleXYZ = glm::vec3(50.0f, 4.0f, 20.0f); 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(20.0f, 0.0f, -80.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("grass");
	SetShaderMaterial("grass");
	SetTextureUVScale(10.0f, 10.0f); 
	m_basicMeshes->DrawSphereMesh();

	/**************************/
	/*   Background Island  2  */
	/**************************/

	scaleXYZ = glm::vec3(20.0f, 6.0f, 40.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-80.0f, 0.0f, 10.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("grass");
	SetShaderMaterial("grass");
	SetTextureUVScale(10.0f, 10.0f);
	m_basicMeshes->DrawSphereMesh();

}